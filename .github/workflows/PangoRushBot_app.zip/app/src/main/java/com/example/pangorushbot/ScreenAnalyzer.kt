package com.example.pangorushbot

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Visual-only runner analyzer. It estimates the player baseline and the nearest
 * obstacle from frame-to-frame image differences and local contrast. No OCR or
 * network access is used. The temporal filter prevents one noisy frame from
 * causing a jump.
 */
object ScreenAnalyzer {
    data class Decision(
        val jump: Boolean,
        val confidence: Float,
        val obstacleDistance: Float,
        val obstacleHeight: Float,
        val playerY: Float
    )

    private var previous: Bitmap? = null
    private var threatFrames = 0
    private var lastPlayerY = 0f

    @Synchronized
    fun reset() {
        previous?.recycle()
        previous = null
        threatFrames = 0
        lastPlayerY = 0f
    }

    @Synchronized
    fun decide(bitmap: Bitmap, sensitivity: Float): Decision {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 200 || h < 200) return Decision(false, 0f, 1f, 0f, 0f)

        // Runner playfield: ignore top HUD and the bottom navigation area.
        val y0 = (h * 0.48f).toInt()
        val y1 = (h * 0.88f).toInt()
        val x0 = (w * 0.08f).toInt()
        val x1 = (w * 0.96f).toInt()

        // Estimate the floor/player band by looking for the strongest horizontal
        // transition. This is deliberately broad because device aspect ratios vary.
        var bestBand = y1 - (h * 0.12f).toInt()
        var bestEnergy = 0f
        val stride = max(4, w / 180)
        for (y in y0 until y1 step stride) {
            var e = 0f
            var n = 0
            for (x in x0 until x1 step stride) {
                val a = luminance(bitmap.getPixel(x, y))
                val b = luminance(bitmap.getPixel(x, min(y + stride, h - 1)))
                e += abs(a - b)
                n++
            }
            val energy = if (n == 0) 0f else e / n
            if (energy > bestEnergy) { bestEnergy = energy; bestBand = y }
        }
        val playerY = bestBand.toFloat() / h
        lastPlayerY = if (lastPlayerY == 0f) playerY else lastPlayerY * .75f + playerY * .25f

        // Find compact, high-contrast blobs ahead of the player. Use column density
        // rather than a single pixel threshold, making it resilient to textures.
        val startX = (w * 0.43f).toInt()
        val endX = (w * 0.91f).toInt()
        val floorY = (h * max(0.60f, min(0.86f, lastPlayerY + 0.10f))).toInt()
        var bestThreat = 0f
        var bestDist = 1f
        var bestHeight = 0f

        for (x in startX until endX step stride) {
            val colWidth = min(stride * 2, endX - x)
            var occupied = 0
            var samples = 0
            var topHit = h
            var bottomHit = 0
            for (xx in x until x + colWidth) {
                for (y in y0 until min(floorY, y1) step stride) {
                    val p = bitmap.getPixel(xx, y)
                    val r = (p shr 16) and 255
                    val g = (p shr 8) and 255
                    val b = p and 255
                    val lum = (r + g + b) / 765f
                    val chroma = (max(r, max(g, b)) - min(r, min(g, b))) / 255f
                    // Local visual candidates: colored/dark structures distinct from a
                    // relatively uniform background. The density is what matters.
                    val hit = chroma > 0.18f || lum < 0.20f || lum > 0.90f
                    if (hit) {
                        occupied++
                        topHit = min(topHit, y)
                        bottomHit = max(bottomHit, y)
                    }
                    samples++
                }
            }
            if (samples == 0) continue
            val density = occupied.toFloat() / samples
            val height = if (bottomHit > topHit) (bottomHit - topHit).toFloat() / h else 0f
            // Obstacles tend to occupy a contiguous vertical patch above the floor.
            val plausible = density > (0.055f - sensitivity * 0.025f) && height > 0.035f
            if (plausible) {
                val distance = (x - startX).toFloat() / (endX - startX)
                val proximity = 1f - distance
                val score = density * 1.5f + height * 0.8f + proximity * 0.45f
                if (score > bestThreat) {
                    bestThreat = score
                    bestDist = distance
                    bestHeight = height
                }
            }
        }

        // Temporal confirmation. The closer the object, the fewer frames are needed.
        val trigger = 0.18f + (1f - sensitivity) * 0.10f
        val closeEnough = bestDist < (0.52f + sensitivity * 0.18f)
        if (bestThreat > trigger && closeEnough) threatFrames++ else threatFrames = max(0, threatFrames - 1)

        val confidence = min(1f, bestThreat / 0.65f)
        val jump = threatFrames >= 2
        return Decision(jump, confidence, bestDist, bestHeight, lastPlayerY)
    }

    private fun luminance(pixel: Int): Float {
        val r = (pixel shr 16) and 255
        val g = (pixel shr 8) and 255
        val b = pixel and 255
        return (0.2126f * r + 0.7152f * g + 0.0722f * b) / 255f
    }
}
